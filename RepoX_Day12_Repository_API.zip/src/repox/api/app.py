"""FastAPI application factory for RepoX."""

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel

from repox.api.schemas import RepositoryCreateRequest, RepositoryCreateResponse
from repox.ingestion import (
    GitHubRepositoryService,
    InvalidRepositoryURLError,
    RepositoryCloneError,
)


class HealthResponse(BaseModel):
    """Liveness response for the HTTP service."""

    status: str
    service: str


def create_app(
    repository_service: GitHubRepositoryService | None = None,
) -> FastAPI:
    """Create the API application without loading models or opening indexes.

    A repository service can be injected by tests or embedding applications.
    """
    app = FastAPI(
        title="RepoX API",
        description="HTTP interface for repository intelligence services.",
        version="0.1.0",
    )
    app.state.repository_service = repository_service or GitHubRepositoryService()

    @app.get("/health", response_model=HealthResponse, tags=["system"])
    def health() -> HealthResponse:
        """Report that the API process is alive."""
        return HealthResponse(status="ok", service="repox-api")

    @app.post(
        "/repositories",
        response_model=RepositoryCreateResponse,
        status_code=status.HTTP_201_CREATED,
        tags=["repositories"],
        summary="Acquire a public GitHub repository",
    )
    def create_repository(
        request: RepositoryCreateRequest,
    ) -> RepositoryCreateResponse:
        """Clone a public GitHub repository into the managed workspace."""
        try:
            checkout = app.state.repository_service.clone(
                request.repository_url,
                branch=request.branch,
            )
        except (InvalidRepositoryURLError, ValueError) as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=str(exc),
            ) from exc
        except RepositoryCloneError as exc:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Repository acquisition failed: {exc}",
            ) from exc

        return RepositoryCreateResponse(
            repository_id=checkout.repository_id,
            owner=checkout.owner,
            name=checkout.name,
            url=checkout.url,
            branch=checkout.branch,
        )

    return app


app = create_app()
