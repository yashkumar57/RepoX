"""Tests for the RepoX HTTP application and repository acquisition route."""

from pathlib import Path
from unittest.mock import Mock

import pytest
from fastapi.testclient import TestClient

from repox.api.app import create_app
from repox.ingestion import (
    InvalidRepositoryURLError,
    RepositoryCheckout,
    RepositoryCloneError,
)


def _checkout() -> RepositoryCheckout:
    return RepositoryCheckout(
        repository_id="a" * 32,
        owner="pallets",
        name="itsdangerous",
        url="https://github.com/pallets/itsdangerous.git",
        branch="main",
        path=Path("/managed/repositories") / ("a" * 32),
    )


def test_health_endpoint_reports_service_liveness() -> None:
    client = TestClient(create_app())

    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok", "service": "repox-api"}


def test_openapi_schema_is_available_and_documents_repository_route() -> None:
    client = TestClient(create_app())

    response = client.get("/openapi.json")

    assert response.status_code == 200
    schema = response.json()
    assert "/health" in schema["paths"]
    assert "/repositories" in schema["paths"]
    assert "post" in schema["paths"]["/repositories"]


def test_create_repository_returns_checkout_metadata() -> None:
    service = Mock()
    service.clone.return_value = _checkout()
    client = TestClient(create_app(repository_service=service))

    response = client.post(
        "/repositories",
        json={
            "repository_url": "https://github.com/pallets/itsdangerous",
            "branch": "main",
        },
    )

    assert response.status_code == 201
    assert response.json() == {
        "repository_id": "a" * 32,
        "owner": "pallets",
        "name": "itsdangerous",
        "url": "https://github.com/pallets/itsdangerous.git",
        "branch": "main",
        "status": "cloned",
    }
    service.clone.assert_called_once_with(
        "https://github.com/pallets/itsdangerous", branch="main"
    )


def test_create_repository_omits_branch_when_not_requested() -> None:
    service = Mock()
    service.clone.return_value = _checkout()
    client = TestClient(create_app(repository_service=service))

    response = client.post(
        "/repositories",
        json={"repository_url": "https://github.com/pallets/itsdangerous"},
    )

    assert response.status_code == 201
    service.clone.assert_called_once_with(
        "https://github.com/pallets/itsdangerous", branch=None
    )


@pytest.mark.parametrize(
    "payload",
    [
        {},
        {"repository_url": ""},
        {"repository_url": "https://github.com/pallets/itsdangerous", "extra": 1},
    ],
)
def test_create_repository_rejects_invalid_request_schema(payload: dict) -> None:
    client = TestClient(create_app(repository_service=Mock()))

    response = client.post("/repositories", json=payload)

    assert response.status_code == 422


def test_create_repository_maps_invalid_github_url_to_422() -> None:
    service = Mock()
    service.clone.side_effect = InvalidRepositoryURLError("Only GitHub HTTPS URLs")
    client = TestClient(create_app(repository_service=service))

    response = client.post(
        "/repositories", json={"repository_url": "https://gitlab.com/a/b"}
    )

    assert response.status_code == 422
    assert response.json()["detail"] == "Only GitHub HTTPS URLs"


def test_create_repository_maps_invalid_branch_to_422() -> None:
    service = Mock()
    service.clone.side_effect = ValueError("Invalid branch name")
    client = TestClient(create_app(repository_service=service))

    response = client.post(
        "/repositories",
        json={"repository_url": "https://github.com/pallets/itsdangerous", "branch": "bad"},
    )

    assert response.status_code == 422
    assert response.json()["detail"] == "Invalid branch name"


def test_create_repository_maps_clone_failure_to_502() -> None:
    service = Mock()
    service.clone.side_effect = RepositoryCloneError("repository not found")
    client = TestClient(create_app(repository_service=service))

    response = client.post(
        "/repositories", json={"repository_url": "https://github.com/a/b"}
    )

    assert response.status_code == 502
    assert response.json()["detail"] == (
        "Repository acquisition failed: repository not found"
    )
