"""Tests for the RepoX HTTP application shell."""

from fastapi.testclient import TestClient

from repox.api.app import create_app


def test_health_endpoint_reports_service_liveness() -> None:
    client = TestClient(create_app())

    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok", "service": "repox-api"}


def test_openapi_schema_is_available() -> None:
    client = TestClient(create_app())

    response = client.get("/openapi.json")

    assert response.status_code == 200
    assert "/health" in response.json()["paths"]
