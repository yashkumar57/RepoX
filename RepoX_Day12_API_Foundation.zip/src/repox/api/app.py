"""FastAPI application factory for RepoX."""

from fastapi import FastAPI
from pydantic import BaseModel


class HealthResponse(BaseModel):
    """Liveness response for the HTTP service."""

    status: str
    service: str


def create_app() -> FastAPI:
    """Create the API application without loading models or opening indexes."""
    app = FastAPI(
        title="RepoX API",
        description="HTTP interface for repository intelligence services.",
        version="0.1.0",
    )

    @app.get("/health", response_model=HealthResponse, tags=["system"])
    def health() -> HealthResponse:
        """Report that the API process is alive."""
        return HealthResponse(status="ok", service="repox-api")

    return app


app = create_app()
